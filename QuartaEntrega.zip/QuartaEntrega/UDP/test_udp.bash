#!/bin/bash
#go run ../../TCP/server.go

go run 	client.go &
go run 	client.go &
go run 	client.go & 
go run 	client.go &
go run 	client.go &
go run 	client.go &
go run 	client.go "teste " &
go run 	client.go &
go run 	client.go &
go run 	client.go & 
go run 	client.go &
go run 	client.go &
go run 	client.go &
go run 	client.go &
go run 	client.go &

































